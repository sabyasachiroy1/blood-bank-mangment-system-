<html>
<head>
  <style>
  #footer {

  position:absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 75px;
  background-color:black;
  color:white;
  text-align: center;
}
  </style>
</head>
<body>
  <div id="footer" >
  <b><center>
  Blood Bank Management System 
  <br>
  ALL RIGHTS RESERVED.
  </center>
  </div>


</body>

</html>
