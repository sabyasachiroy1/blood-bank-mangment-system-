<?php
@$name=$_POST['fullname'];
@$number=$_POST['mobileno'];
@$email=$_POST['emailid'];
@$age=$_POST['age'];
@$gender=$_POST['gender'];
@$blood_group=$_POST['blood'];
@$address=$_POST['address'];
@$conn=mysqli_connect("localhost","root","","blood_donation") or die("Connection error");
if (strlen($number)==10)
{
@$sql= "INSERT INTO donor_details(donor_name,donor_number,donor_mail,donor_age,donor_gender,donor_blood,donor_address) values('{$name}','{$number}','{$email}','{$age}','{$gender}','{$blood_group}','{$address}')";
@$result=mysqli_query($conn,$sql) or die("query unsuccessful.");
mysqli_close($conn);
echo "<script>
location.replace ('http://localhost/conformation.php');
alert(' Registration done')</script>";
}
else {
    echo "<script>
alert('Mobile Number Should Be In 10 Digits ')</script>";
}
 
 ?>
