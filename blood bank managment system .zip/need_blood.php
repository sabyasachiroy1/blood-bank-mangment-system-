<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>
  <?php 
  $active ='need';
  include('head.php') ?>
<div id="page-container" style="margin-top:50px; position: relative;min-height: 84vh;">
    <div class="container">
    <div id="content-wrap" style="padding-bottom:50px;">
<div class="row">
<div class="col-lg-6">
<h1 class="mt-4 mb-3">Need Blood</h1>
</div>
  </div>
  <form name="needblood" method="post"> 
  <div class="row">
  <div class="col-lg-4 mb-4">
  <div class="font-italic">Blood Group<span style="color:red">*</span></div>
  <div><select name="blood" class="form-control" required>
  <option value="0">Select</option>
  <option value="1">B+</option>
  <option value="2">B-</option>
  <option value="3">A+</option>
  <option value="4">O+</option>
  <option value="5">O-</option>
  <option value="6">A-</option>
  <option value="7">AB+</option>
  <option value="8">AB-</option>
</select>
</div>
</div>
<div class="col-lg-4 mb-4">
<div class="font-italic">Reason, why do you need blood?<span style="color:red">*</span></div>
<div><textarea class="form-control" name="address" required></textarea></div></div>
</div>
<div class="row">
<div class="col-lg-4 mb-4">
<div><input type="submit" name="search" class="btn btn-primary" value="Search" style="cursor:pointer"></div>
</div>
</div>
</div>
</div>
</form>
<?php
include 'conn.php';
   if (isset($_POST['search']))
   {
    $b =$_POST['blood'];
    if ($b=='0')
    {
       echo "<b style='color:red '>Select The Blood Group </b>";
    }
    else { 
      $b= $_POST['blood'];
      $qu= "select * from donor_details join blood where donor_details.donor_blood=blood.blood_id
       AND donor_blood='$b' order by rand() limit 5";
      $s=mysqli_query($conn,$qu);
      if (!$s) {
        echo "<script>alert('Technical Problem Occured ');</script>";
      }
      else {
         echo "<div class='donardatasets'>";
        echo" <table style='width:100%'>";
         echo"<tr>";
         echo "<th>Id </th>";
           echo "<th>Name</th>";
           echo"<th>Gender </th>";
           echo"<th>Blood Group</th>";
           echo"<th>Age </th>";
           echo"<th>Contact No</th>"; 
           echo"<th>Mail Id </th>";
           echo"<th>Adress</th>";
           echo"<th>Status</th>";
          echo"</tr>";
          // dataparts 
          while ($r= mysqli_fetch_assoc($s))
          {
           
              echo "<tr>";
            echo "<td>";
            echo $r['donor_id'];
            echo "</td>";
            echo "<td>";
            echo $r['donor_name'];
            echo "</td>";
            echo "<td>";
            echo $r['donor_gender'];
            echo "</td>";
            echo "<td>";
            echo $r['blood_group'];
            echo "</td>";
            echo "<td>";
            echo $r['donor_age'];
            echo "</td>";
            echo "<td>";
            echo $r['donor_number'];
            echo "</td>";
            echo "<td>";
            echo $r['donor_mail'];
            echo "</td>";
            echo "<td>";
            echo $r['donor_address'];
            echo "</td>";
            echo "<td>";
            echo "<b style='color:green'>Active </B>";
            echo "</td>";
            
            echo "</tr>";
            
          }
        
       echo" </table>";
         echo "</div>";
         
        
       
      }
    }
   
    
  }
  
  
?>
<?php include 'footer.php' ?>
</div>
</body>

</html>

</head>
<body>


<style>
  .donardatasets {
 
    overflow: auto;
    margin-top: -60px;
    height: 40%;
    padding-left:3px;
    
  }
  table, th, td {
  border: 1px solid black;
  font-size: large;
  font-weight: bold;
  overflow: auto;
  color: black;
  
}
th {
  background-color:darkblue;
  color: white;
}
</style>