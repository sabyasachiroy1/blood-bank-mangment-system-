<?php
include 'conn.php';
if(isset($_POST['validationbuttons']))
{
    $a= $_POST['validationquery'];
     $q= "select query_id from contact_query where query_id='$a'";
     $qtodbs =mysqli_query($conn,$q);
     $r=mysqli_fetch_assoc($qtodbs);
     if (@$r['query_id']==$a)
     {
           $eqs = "update contact_query set query_status='1' where query_id='$a'";
           $cons= mysqli_query($conn,$eqs);
           if ($cons ){
            echo "<script>alert (' ✅ Issue Resolved Sucessfully');</script>";
           }
          
     }
     else {
        echo "<script>alert (' ❌ Query Id Doesnot Found ');</script>";
       }

}
echo "<script>location.replace('http://localhost/admin/query.php');</script>";
 ?>
