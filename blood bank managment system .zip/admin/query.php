<html>
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
#sidebar{position:relative;margin-top:-20px}
#content{position:relative;margin-left:210px}
@media screen and (max-width: 600px) {
  #content {
    position:relative;margin-left:auto;margin-right:auto;
  }
}
  #he{
      font-size: 14px;
      font-weight: 600;
      text-transform: uppercase;
      padding: 3px 7px;
      color: #fff;
      text-decoration: none;
      border-radius: 3px;
      text-align:center;
  }
</style>
</head>
<?php
include 'conn.php';
include 'session.php';
?>
<body style="color:black">
<div id="header">
<?php include 'header.php';
?>
</div>
<div id="sidebar">
<?php $active="query"; include 'sidebar.php'; ?>

</div>
<div id="content" >
  <div class="content-wrapper">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12 lg-12 sm-12">

          <h1 class="page-title">User Query</h1>

        </div>

      </div>
      <hr>
      
   <fieldset style="border: 2px solid black;height:50%; overflow:auto",>
   <table border="1px solid black" style="width:100%">
    <thead>
      <tr>
        <td> <b>Id </b></td>
        <td>
          <b> Name  </b>
        </td>
        <td>
          <b>Mail </b>
        </td>
        <td>
          <b> Contact No </b>
        </td>
        <td>
          <b>message</b>
        </td>
        <td>
          <b> Query Date </b>
        </td>
        <td>
          <b> Action </b>
        </td>
      </tr>
    </thead>
    <tbody>
      
    <?php 
     $query ="SELECT * FROM contact_query WHERE query_status='0' order by query_id desc;";
     $dtodd= mysqli_query($conn,$query);
      while ($row=mysqli_fetch_assoc($dtodd))
      { echo "<tr>";
        echo "<td>";
        echo $row['query_id'];
        echo "</td>";
        echo "<td>";
        echo $row['query_name'];
        echo "</td>";
        echo "<td>";
        echo $row['query_number'];
       
        echo "</td>";
        echo "<td>";
         echo $row['query_mail'];
        
        echo "</td>";
        echo "<td>";
        echo $row['query_message'];
        echo "</td>";
        echo "<td>";
        echo $row['query_date'];
        echo "</td>";
        echo "<td>";
        $a= $row['query_status'];
        if ($a==0)
        echo "<button style=' color:white;background-color:red'>No action Taken</a></button>";
        echo "</form>";
        echo "</td>";
        echo "<tr>";
      }
   
    ?>
    <tr>
    </tbody>
   </table>
    
   </fieldset>
     
 <?php
include 'conn.php';

?>
    

   </body>
</html>
<style>
  th ,td {
    padding: 8px;
  }
</style>
<!-- issue resolved  -->
<form method="post" action="query_end_message.php">
<fieldset>
  <table >
    <tr>
      <td>
        <b>Query Id </b>

      </td>
      <td><input type="text" required name="validationquery" autofocus></td>
      <td><button style="background-color: green; color:white;border-radius:12px" name="validationbuttons">Take Action </button></td>
    </tr>
    
  </table>
</fieldset>
</form>