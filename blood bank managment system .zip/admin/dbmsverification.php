<?php
session_start();
$host = 'localhost';
$user='root';
$pas='';
$db ='blood_donation';
$con = mysqli_connect($host,$user,$pas,$db);
if(isset($_POST['buttonpress'])){
      @$a = $_POST['userids'];
      @$b =$_POST['passkeys'];
    $query ="select password from dbmsadmin where adminid ='$a'";
     $qtodb =mysqli_query($con,$query);
     $s= mysqli_fetch_assoc($qtodb);
    $pas= $s["password"];
    if ($b==$pas) {
        echo '<script>alert("Welcome Dbms Amin "); location.replace ("http://localhost/phpmyadmin/index.php?route=/database/structure&db=blood_donation");</script>';
    }
    else {
        echo '<script>alert("Invalid Credentials"); location.replace("http://localhost/admin/dbmslogin.php");</script>';
    }
     
     
}

session_abort();
 ?>