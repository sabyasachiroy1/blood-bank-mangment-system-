
<html lang="en">
<head>
    <meta charset="UTF-8"></meta>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"></meta>
    <title>DATABASE ADMIN </title>
</head>
<body>
<form action="/admin/dbmsverification.php" method="post">
<table class="tableone">
   <thead>
    <tr>
     <td class="banners">
     <h3>Database Admin Login </h3>
     </td>
    </tr>
    </thead>
</table>
<table class="nexttable">
 <tr>
    <td>
        <label for="userid"><strong>USERID<sup>*</sup>  </strong></label>
    </td>
 </tr>
 <tr>
    <td>
        <input id="userid" required="" type="text"  name="userids"/>
    </td>
    
 </tr>
 <tr>
    <td>
        <label for="password"><strong>PASSWORD<sup>*</sup>   </strong></label>
    </td>
 </tr>
 <tr>
    <br />
 </tr>
 <tr>
    <td>
        <input id="password" required="" type="password" name="passkeys" />
    </td>
 </tr>
 <tr>
    <td>
        <input id="dateandtimess" type="text" style="display: none;"/>
    </td>
 </tr>
 

 <tr>
    <td>
        <button name="buttonpress"> LOGIN </button>
    </td>
    
 </tr>
 
</table>
</form>
</body>


</html>

<style>
    *{
    margin: 0;
    padding: 0;
}
.banners{
    background-color: rgb(6, 6, 35);
    color: white;
    text-align: center;
}
label {
    font-family: 2em;
   
}
table {
    width: 100%;
}
.tableone {
   
    height: 10vh;
    font-size: 1em;
    
}
.nexttable {
    margin-top: 10px;
    padding-left: 10px;
}
input ,.inputss{
    height: 4vh;
    width: 95%;
    font-size: 1em;
    
    margin: 4px;
}
.inputss {
    margin-left: 15px;
}
button {
    height:4vh;
    width: 15%;
    background-color: rgb(255, 0, 0);
    color: white;
    min-width: fit-content;
    margin-top:11px;
    margin-bottom: 5px;
    font-weight: bolder;
    border-radius: 5px;

}
sup {
    color: red;
    font-size: larger;
}

</style>

<script>
    
</script>