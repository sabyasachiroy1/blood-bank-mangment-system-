

<html>
<head>
<style>
@media screen and (max-width: 80px) {
  .news {
    position:relative;margin-left:auto;margin-right:auto;margin-top:400px  ;
  }
  .text1{
  	box-shadow:none !important;
    position:relative;
      margin-left:auto;margin-right:auto;
  }
}
.blue {
    background: #347fd0;
}

.news {
    box-shadow: inset 0 -15px 30px rgba(10,4,60,0.4), 0 5px 10px rgba(10,20,100,0.5);
       width: 100%;
       height:50px;
    margin-top:0px;
    overflow: hidden;

    border-radius: 4px;
    padding: 1px;
    -webkit-user-select: none;

}


.news span {
    float: left;
    color: #fff;
    padding: 9px;
    position: relative;
    top: 1%;
    box-shadow: inset 0 -15px 30px rgba(0,0,0,0.4);
    font: 16px 'Raleway', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -webkit-user-select: none;
    cursor: pointer;
}

.text1{

	box-shadow:none !important;
  position:relative;
    width:90%
}
</style>
</head>
<body>
<div class="news blue" style="background-color:darkolivegreen;">
<span style="background-color:red;width:125px;height:50px">Latest Updates</span><span class="text1" ><marquee>Blood Bank Managment System Devloped By uemk Students  </marquee></span>
</div>
</body>
</head>
</html>
