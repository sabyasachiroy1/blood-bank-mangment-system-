
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Conformations </title>
</head>
<body>
<table>
  <tr>
    <td>
      <img src="/sucessfullydone.gif" style="height:50%px;">
    </td>
    <td><h2 style="color: green;"><b>Donar Registred Sucessfully</b><br>Your Email Id Will Be Your User Id </a> </h2> <br> <button style="background-color: blue; color:white"><a href="http://localhost/" style="text-decoration:none; color:white">Back</a></button></td>
  </tr><td><marquee style="color: red; font-size: large;">
  <b>Blood Donation Will Cost You Nothing , But It Will Save A Life</b></marquee></td>
  <tr>
    
  </tr>
</table>

</body>
</html>
<?php include('footer.php') ?>